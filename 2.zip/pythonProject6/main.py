import pygame
import sys
from hero import Hero



def start_game():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Space Invaders")
    screen_rect = screen.get_rect()
    bg = pygame.image.load("Background/space.png")




    hero = Hero(screen)


    flag = True
    while flag:

        for event in pygame.event.get():

            screen.blit(bg, (0, 0))
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_d:
                    hero.move_right = True
                if event.key == pygame.K_a:
                    hero.move_left = True
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_d:
                    hero.move_right = False
                if event.key == pygame.K_a:
                    hero.move_left = False
                # hero.rect.clamp_ip(screen_rect)



        pygame.display.flip()
        screen.fill(0)
        hero.output_hero()
        hero.moving_hero(screen)



start_game()